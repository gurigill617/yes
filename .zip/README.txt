1. Install Node.js
2. Open terminal inside this folder
3. Run: npm install
4. Put your bot TOKEN in .env
5. Put your clientId & guildId in config.json
6. Register slash commands:
   npm run deploy
7. Start bot:
   npm start
